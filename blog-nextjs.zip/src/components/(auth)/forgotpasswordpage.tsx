
export default function ForgotPasswordPage() {
    return (
        <>
            <div className="forgot-password_box">

            </div>
        </>
    );
}
