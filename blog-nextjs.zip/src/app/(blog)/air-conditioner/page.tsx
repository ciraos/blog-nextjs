import { Metadata } from "next"

export const metadata: Metadata = {
    title: "小空调"
}

export default function AirConditioner() {
    return (
        <></>
    )
}
