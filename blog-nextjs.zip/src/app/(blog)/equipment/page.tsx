import { Metadata } from "next"

export const metadata: Metadata = {
    title: "我的装备"
}

export default function Equipment() {
    return (
        <></>
    )
}
