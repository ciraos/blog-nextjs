/*
 * Server page 
*/
import type { Metadata } from "next";

export const metadata: Metadata = {
    title: "友情链接",
};

export default async function LinkPage() {
    return (
        <>
            <h2>友情链接</h2>
        </>
    )
}
