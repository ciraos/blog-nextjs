import { Metadata } from "next";

export const metadata: Metadata = {
    title: "朋友动态"
};

export default function Fcircle() {
    return (
        <>
            <h2>朋友动态</h2>
        </>
    );
}
