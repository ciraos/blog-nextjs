import { Metadata } from "next"

export const metadata: Metadata = {
    title: "相册集"
}

export default function Album() {
    return (
        <></>
    )
}
