import { Metadata } from "next"

export const metadata: Metadata = {
    title: "音乐馆"
}

export default function Music() {
    return (
        <></>
    )
}
