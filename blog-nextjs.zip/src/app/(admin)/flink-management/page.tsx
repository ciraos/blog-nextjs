import { Metadata } from "next";

export const metadata: Metadata = {
    title: "友链管理",
};

export default function FlinkManagement() {
    return (<></>);
}
