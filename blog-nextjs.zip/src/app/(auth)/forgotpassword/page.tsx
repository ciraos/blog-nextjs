import type { Metadata } from "next";

export const metadata: Metadata = {
    title: "忘记密码",
    description: "忘记密码了吗，小笨蛋！！",
};

export default function ForgotPassword() {
    return (
        <></>
    );
}
