
//!
export interface RenJianResponse {
    code: number;
    msg: string;
    data: string;
    request_id: string;
}
